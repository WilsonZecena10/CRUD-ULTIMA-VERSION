package service;

public class Menus {
        
    public void menu  (){
    System.out.println();
    System.out.println();
    System.out.println("*********************************");
    System.out.println("1) Ingresar registros            ");
    System.out.println("2) Buscar registros              ");
    System.out.println("3) Actualizar registros          ");
    System.out.println("4) Borrar registros              ");
    System.out.println("5) Imprimir registros            ");
    System.out.println("6) Salir                         ");
    System.out.println("*********************************");
    System.out.println();
    System.out.print("Ingrese opcion: ");
    }
    
    public void subMenu(){
    System.out.println();
    System.out.println();
    System.out.println("*********************************");
    System.out.println("1) Registrar personal Administrativo");
    System.out.println("2) Registrar Catedraticos");
    System.out.println("3) Registrar Alumnos");
    System.out.println("4) Salir");
    System.out.println("*********************************");
    System.out.println();
    System.out.print("Ingrese opcion: ");
    
    }
}
